package com.pets.constants;

public class Endpoints {

        public static final String AddNew_Pet = "/pet";
        public static final String Delete_Pet = "/pet/{petId}";
        public static final String Buy_Pet = "/store/order";
        public static final String Find_PurchaseOrder = "/store/order/{orderId}";

}
