Allure Report for the Test cases
First three was working and fourth was failed intentionally to generate failure report.
![img_2.png](img_2.png)
This is the folder structure for the Rest Assured Framework
![img.png](img.png)
To generate the allure report run this command from allure bin folder
![img_1.png](img_1.png)




